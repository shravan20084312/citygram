INSERT INTO user (name, username, password) 
VALUES ('Luv Gupta', 'sa_admin', '$2a$10$wBv9Kga5UabBurwcY8QZg.SPNPWhpUc3rOEyanTkKgnpoJOajSF0O');