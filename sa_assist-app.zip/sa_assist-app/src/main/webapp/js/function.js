/*global jQuery:false */
jQuery(document).ready(function($) {
"use strict";
 


})(jQuery);