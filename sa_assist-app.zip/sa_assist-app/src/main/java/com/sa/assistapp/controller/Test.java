/**
 * 
 */
package com.sa.assistapp.controller;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.sa.assistapp.model.SolrDocumentFiltered;

/**
 * @author lugupta
 *
 */
public class Test {

	/**
	 * @param args
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * @throws ParseException
	 */
	public static void main(String[] args) throws Exception {
		/*
		 * // TODO Auto-generated method stub ObjectMapper objectMapper = new
		 * ObjectMapper(); List<SolrDocument> emp = objectMapper.readValue(new
		 * File("C:\\SA-AssistApp\\sampleJson.json"),
		 * objectMapper.getTypeFactory().constructCollectionType(List.class,
		 * SolrDocument.class)); System.out.println(emp.size());
		 */

	String x = "L21";
	System.out.println("L2-1".replace("-", ""));
	System.out.println(x.contains("L2-1".replace("-", "")));
	}
}
