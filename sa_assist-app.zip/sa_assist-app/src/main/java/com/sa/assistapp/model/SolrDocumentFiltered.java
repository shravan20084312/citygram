/**
 * 
 */
package com.sa.assistapp.model;

/**
 * @author lugupta
 *
 */
public class SolrDocumentFiltered {

	private String key;
	private String version;
	private String description;
	private String endpoint;
	private String env;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	@Override
	public String toString() {
		return "SolrDocumentFiltered [key=" + key + ", version=" + version + ", description=" + description
				+ ", endpoint=" + endpoint + ", env=" + env + "]";
	}
}
