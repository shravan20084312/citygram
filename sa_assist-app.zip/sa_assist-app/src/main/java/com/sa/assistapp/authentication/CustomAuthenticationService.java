/**
 * 
 */
package com.sa.assistapp.authentication;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sa.assistapp.constants.GenericConstants;
import com.sa.assistapp.dao.UserDAO;
import com.sa.assistapp.model.LoginDetails;

/**
 * This class implements Spring Security User Details Service to load user
 * specific data
 * 
 * @author lugupta
 */
@Service
public class CustomAuthenticationService implements UserDetailsService {

	private static final Logger logger = Logger.getLogger(CustomAuthenticationService.class);
	private static final Logger errorLogger = Logger.getLogger(GenericConstants.LOGGER_ERROR_NAME);

	@Autowired
	private UserDAO userDAO;

	@Override
	public UserDetails loadUserByUsername(String userName) {

		try {
			logger.debug("START loadUserByUsername() in CustomAuthenticationService.class");

			LoginDetails loginDetails = userDAO.findUserByUserName(userName);

			if (null == loginDetails) {
				errorLogger.error("Classname: CustomAuthenticationService. Login Detail with username " + userName
						+ " not present in the database");
				logger.error("Username " + userName + " not found in the db");

				throw new UsernameNotFoundException(
						"Login Details with username " + userName + " was not found in the database");
			}

			logger.debug("Full Name: " + loginDetails.getFullName());

			List<GrantedAuthority> grantList = new ArrayList<>();
			GrantedAuthority authority = new SimpleGrantedAuthority(
					GenericConstants.ROLE_UNDERSCORE + GenericConstants.ROLE_ADMIN);
			grantList.add(authority);

			UserDetails userDetails = new User(loginDetails.getUserName(), loginDetails.getPassword(), grantList);

			logger.debug("END loadUserByUsername() in CustomAuthenticationService.class");

			return userDetails;
		} catch (Exception e) {
			errorLogger.error("Classname: CustomAuthenticationService. Login Details with username " + userName
					+ " was not found in the database" + e);
			logger.error("Username " + userName + " not available" + e);

			throw new UsernameNotFoundException("Username " + userName + " missing");
		}
	}

}