/**
 * 
 */
package com.sa.assistapp.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sa.assistapp.model.LoginDetails;

/**
 * @author lugupta
 *
 */
public class LoginDetailsMapper implements RowMapper<LoginDetails> {

	@Override
	public LoginDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		LoginDetails loginDetails = new LoginDetails();

		loginDetails.setId(rs.getInt("id"));
		loginDetails.setFullName(rs.getString("name"));
		loginDetails.setUserName(rs.getString("username"));
		loginDetails.setPassword(rs.getString("password"));

		return loginDetails;
	}

}