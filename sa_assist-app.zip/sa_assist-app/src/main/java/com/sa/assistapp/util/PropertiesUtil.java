package com.sa.assistapp.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.springframework.stereotype.Component;

/**
 * @author lugupta
 *
 */
@Component
public class PropertiesUtil {

	private PropertiesUtil() {
	}

	/**
	 * Get the property from the class-path .
	 */
	public static Properties loadFromClasspath(String propsName) throws Exception {
		Properties props = new Properties();
		URL url = ClassLoader.getSystemResource(propsName);
		props.load(url.openStream());
		return props;
	}

	/**
	 * Load all the Properties File
	 */
	public static Properties load(String propsFileName) throws IOException {
		File propsFile = new File(propsFileName);
		Properties props = new Properties();
		FileInputStream fis = new FileInputStream(propsFile);
		props.load(fis);
		fis.close();
		return props;
	}

	/**
	 * Update the Properties File
	 */
	public static void update(String propsFileName, String propsKey, String propsValue) throws IOException {
		File propsFile = new File(propsFileName);
		Properties props = load(propsFileName);
		props.setProperty(propsKey, propsValue);
		FileOutputStream fos = new FileOutputStream(propsFile);
		props.store(fos, null);
		fos.close();
	}

	/**
	 * Update the Properties File and return updated Property object
	 */
	public static Properties updateAndReturn(String propsFileName, String propsKey, String propsValue)
			throws IOException {
		File propsFile = new File(propsFileName);
		Properties props = load(propsFileName);
		props.setProperty(propsKey, propsValue);
		FileOutputStream fos = new FileOutputStream(propsFile);
		props.store(fos, null);
		fos.close();
		props = load(propsFileName);
		return props;
	}

}