/**
 * 
 */
package com.sa.assistapp.dao.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sa.assistapp.constants.GenericConstants;
import com.sa.assistapp.dao.UserDAO;
import com.sa.assistapp.mapper.LoginDetailsMapper;
import com.sa.assistapp.model.LoginDetails;

/**
 * @author lugupta
 *
 */
@Repository
public class UserDAOImpl implements UserDAO {

	private static final Logger logger = Logger.getLogger(UserDAOImpl.class);
	public static final Logger errorLogger = Logger.getLogger(GenericConstants.LOGGER_ERROR_NAME);

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	/* Fetch login details based on username */
	@Override
	public LoginDetails findUserByUserName(String userName) throws Exception {
		Map<String, Object> params = new HashMap<>();
		params.put("userName", userName);

		String sql = "SELECT * FROM user WHERE username=:userName";

		LoginDetails loginDetailsObj = null;

		try {
			loginDetailsObj = namedParameterJdbcTemplate.queryForObject(sql, params, new LoginDetailsMapper());
		} catch (EmptyResultDataAccessException e) {
			errorLogger.error("No Login Details found with this username " + e);
			logger.error(e);
			return null;
		}

		return loginDetailsObj;
	}
}
