/**
 * 
 */
package com.sa.assistapp.model;

import java.math.BigInteger;

/**
 * @author lugupta
 *
 */
public class SolrDocument {

	private BigInteger _version_;
	private String creationtimestamp;
	private String description;
	private String description_alt;
	private String endpoint;
	private String endpoint_alt;
	private String env;
	private String envMajor;
	private String envSub;
	private String env_alt;
	private String id;
	private String importdate;
	private String l_lastmodified;
	private String lastmodified;
	private String lastmodifiedby;
	private String name;
	private String name_alt;
	private String namespace;
	private String owner;
	private Boolean retired;
	private String sign;
	private String svcpw;
	private String svcuser;
	private String version;

	public BigInteger get_version_() {
		return _version_;
	}

	public void set_version_(BigInteger _version_) {
		this._version_ = _version_;
	}

	public String getCreationtimestamp() {
		return creationtimestamp;
	}

	public void setCreationtimestamp(String creationtimestamp) {
		this.creationtimestamp = creationtimestamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription_alt() {
		return description_alt;
	}

	public void setDescription_alt(String description_alt) {
		this.description_alt = description_alt;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getEndpoint_alt() {
		return endpoint_alt;
	}

	public void setEndpoint_alt(String endpoint_alt) {
		this.endpoint_alt = endpoint_alt;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getEnvMajor() {
		return envMajor;
	}

	public void setEnvMajor(String envMajor) {
		this.envMajor = envMajor;
	}

	public String getEnvSub() {
		return envSub;
	}

	public void setEnvSub(String envSub) {
		this.envSub = envSub;
	}

	public String getEnv_alt() {
		return env_alt;
	}

	public void setEnv_alt(String env_alt) {
		this.env_alt = env_alt;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getImportdate() {
		return importdate;
	}

	public void setImportdate(String importdate) {
		this.importdate = importdate;
	}

	public String getL_lastmodified() {
		return l_lastmodified;
	}

	public void setL_lastmodified(String l_lastmodified) {
		this.l_lastmodified = l_lastmodified;
	}

	public String getLastmodified() {
		return lastmodified;
	}

	public void setLastmodified(String lastmodified) {
		this.lastmodified = lastmodified;
	}

	public String getLastmodifiedby() {
		return lastmodifiedby;
	}

	public void setLastmodifiedby(String lastmodifiedby) {
		this.lastmodifiedby = lastmodifiedby;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName_alt() {
		return name_alt;
	}

	public void setName_alt(String name_alt) {
		this.name_alt = name_alt;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Boolean getRetired() {
		return retired;
	}

	public void setRetired(Boolean retired) {
		this.retired = retired;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getSvcpw() {
		return svcpw;
	}

	public void setSvcpw(String svcpw) {
		this.svcpw = svcpw;
	}

	public String getSvcuser() {
		return svcuser;
	}

	public void setSvcuser(String svcuser) {
		this.svcuser = svcuser;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "SolrDocument [_version_=" + _version_ + ", creationtimestamp=" + creationtimestamp + ", description="
				+ description + ", description_alt=" + description_alt + ", endpoint=" + endpoint + ", endpoint_alt="
				+ endpoint_alt + ", env=" + env + ", envMajor=" + envMajor + ", envSub=" + envSub + ", env_alt="
				+ env_alt + ", id=" + id + ", importdate=" + importdate + ", l_lastmodified=" + l_lastmodified
				+ ", lastmodified=" + lastmodified + ", lastmodifiedby=" + lastmodifiedby + ", name=" + name
				+ ", name_alt=" + name_alt + ", namespace=" + namespace + ", owner=" + owner + ", retired=" + retired
				+ ", sign=" + sign + ", svcpw=" + svcpw + ", svcuser=" + svcuser + ", version=" + version + "]";
	}

}
