/**
 * 
 */
package com.sa.assistapp.form;

/**
 * @author lugupta
 *
 */
public class DashboardForm {

	private String envName;
	private String domainName;

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
}
