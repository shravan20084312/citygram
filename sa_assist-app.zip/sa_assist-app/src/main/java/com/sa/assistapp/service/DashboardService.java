/**
 * 
 */
package com.sa.assistapp.service;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

/**
 * @author lugupta
 *
 */
public interface DashboardService {

	String findFullNameByUserName(String userName) throws Exception;

	void validateSolrKeys(String envName) throws Exception;

	boolean pingURL(String url, int timeout) throws MalformedURLException, UnknownHostException, IOException;
}
