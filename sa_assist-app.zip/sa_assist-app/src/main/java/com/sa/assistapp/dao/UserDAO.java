/**
 * 
 */
package com.sa.assistapp.dao;

import com.sa.assistapp.model.LoginDetails;

/**
 * @author lugupta
 *
 */
public interface UserDAO {

	LoginDetails findUserByUserName(String userName) throws Exception;

}
