/**
 * 
 */
package com.sa.assistapp.service.impl;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.sa.assistapp.dao.UserDAO;
import com.sa.assistapp.model.SolrDocumentFiltered;
import com.sa.assistapp.service.DashboardService;
import com.sa.assistapp.util.PdfWriter;

/**
 * @author lugupta
 *
 */
@Service
@PropertySource("classpath:sa-assistapp.properties")
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private Environment env;

	@Autowired
	private ServletContext servletContext;

	@Autowired
	UserDAO userDAO;

	@Override
	public String findFullNameByUserName(String userName) throws Exception {
		return userDAO.findUserByUserName(userName).getFullName();
	}

	@Override
	public boolean pingURL(String url, int timeout) throws MalformedURLException, UnknownHostException, IOException {
		url = url.replaceFirst("^https", "http"); // Otherwise an exception may be thrown on invalid SSL certificates.

		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		connection.setConnectTimeout(timeout);
		connection.setReadTimeout(timeout);
		connection.setRequestMethod("HEAD");
		int responseCode = connection.getResponseCode();

		return responseCode == HttpURLConnection.HTTP_OK;
	}

	@Override
	public void validateSolrKeys(String envName) throws Exception {
		String solrEnvName = null, solrL4 = null;
		String solrKeysLocEnvName = env.getProperty("default.path") + envName + ".json";
		String solrKeysLocL4 = env.getProperty("default.path") + "L4.json";

		if (envName.equalsIgnoreCase(env.getProperty("default.envname"))) {
			solrEnvName = env.getProperty("solr.l2.url") + env.getProperty("solr.l2.core");
		} else {
			solrEnvName = env.getProperty("solr.l1.url") + env.getProperty("solr.l1.core");
		}
		solrL4 = env.getProperty("solr.l4.url") + env.getProperty("solr.l4.core");

		/*
		 * String[] l4Args = { "-s", solrL4, "-a", "export", "-o", solrKeysLocL4 };
		 * App.main(l4Args);
		 */
		Process proc = Runtime.getRuntime().exec(
				"java -jar C:\\SA-AssistApp\\import-export-1.0.jar -s " + solrL4 + " -a export -o " + solrKeysLocL4);
		proc.waitFor();
		InputStream in = proc.getInputStream();
		byte a[] = new byte[in.available()];
		in.read(a, 0, a.length);
		System.out.println(new String(a));
		InputStream err = proc.getErrorStream();
		byte b[] = new byte[err.available()];
		err.read(b, 0, b.length);
		System.out.println(new String(b));

		/*
		 * String[] envSpecificArgs = { "-s", solrEnvName, "-a", "export", "-o",
		 * solrKeysLocEnvName }; App.main(envSpecificArgs);
		 */
		Process proc1 = Runtime.getRuntime().exec("java -jar C:\\SA-AssistApp\\import-export-1.0.jar -s " + solrEnvName
				+ " -a export -o " + solrKeysLocEnvName);
		proc.waitFor();
		InputStream in1 = proc1.getInputStream();
		byte a1[] = new byte[in1.available()];
		in1.read(a1, 0, a1.length);
		System.out.println(new String(a1));
		InputStream err1 = proc1.getErrorStream();
		byte b1[] = new byte[err1.available()];
		err1.read(b1, 0, b1.length);
		System.out.println(new String(b1));

		List<SolrDocumentFiltered> solrKeysL4 = saveSolrKeysToList("L4-1", solrKeysLocL4);
		List<SolrDocumentFiltered> solrKeysEnvName = saveSolrKeysToList(envName, solrKeysLocEnvName);

		/*
		 * List<SolrDocumentFiltered> solrKeysL4 = saveSolrKeysToList("L4-1",
		 * env.getProperty("json.file.l4")); List<SolrDocumentFiltered> solrKeysEnvName
		 * = saveSolrKeysToList(envName, env.getProperty("json.file.l2"));
		 */

		List<String> keysL4 = solrKeysL4.stream().map(SolrDocumentFiltered::getKey).distinct()
				// .peek(s -> System.out.println("PRD:" + s))
				.collect(Collectors.toList());
		Set<String> unavailableItems = solrKeysEnvName.stream().map(SolrDocumentFiltered::getKey)
				// .peek(s -> System.out.println("Lower:" + s))
				.collect(Collectors.toSet());

		Predicate<String> condition = new Predicate<String>() {
			@Override
			public boolean test(String n) {
				if (!unavailableItems.contains(n)) {
					return true;
				}
				return false;
			}
		};

		Set<String> unavailable = keysL4.stream().filter(condition)
				// .peek(s -> System.out.println("Output:" + s))
				.collect(Collectors.toSet());

		PdfWriter pdf = new PdfWriter();
		pdf.write(servletContext.getRealPath("\\") + "/SOLR_Keys_Result.pdf", solrKeysL4, unavailable,
				env.getProperty("solr.l4.core"), env.getProperty("solr.l2.core"), solrKeysL4.size(),
				solrKeysEnvName.size(), envName);
	}

	@SuppressWarnings("unchecked")
	private List<SolrDocumentFiltered> saveSolrKeysToList(String envName, String jsonPath) throws Exception {
		JSONParser jsonParser = new JSONParser();
		List<SolrDocumentFiltered> solrList = new ArrayList<SolrDocumentFiltered>();
		Object object = jsonParser.parse(new FileReader(jsonPath));
		JSONArray jsonArray = (JSONArray) object;

		jsonArray.forEach(tempObj -> {
			SolrDocumentFiltered obj = mapJsonToPojo(envName, (JSONObject) tempObj);
			if (obj != null) {
				solrList.add(obj);
			}
		});

		return solrList;
	}

	private SolrDocumentFiltered mapJsonToPojo(String envName, JSONObject jsonObj) {
		SolrDocumentFiltered obj = new SolrDocumentFiltered();
		if (envName.contains("L4-1")) {
			String name = (String) jsonObj.get("name");
			if (!(name.contains("_L41") || name.contains("_L4-1"))) {
				name += "_<ENV_NAME>";
			}
			name = name.replace("_L41", "_<ENV_NAME>").replace("_L4-1", "_<ENV_NAME>");
			obj.setKey(name);
			obj.setVersion((String) jsonObj.get("version"));
			obj.setDescription((String) jsonObj.get("description"));
			obj.setEndpoint((String) jsonObj.get("endpoint"));
			return obj;
		} else {
			String env = (String) jsonObj.get("env");
			String[] envCombination = { envName, envName.replace("-", ""), "Lxx", envName.replace("-", "") + "LITE",
					envName.replace("-", "") + "CL", envName.replace("-", "") + "AGG", envName + "-LITE",
					envName + "-CL", envName + "-AGG", };

			if (Arrays.stream(envCombination).parallel().anyMatch(env::equals)) {
				String name = (String) jsonObj.get("name");
				if (!(name.contains("_" + envName) || name.contains("_" + envName.replace("-", "")))) {
					name += "_<ENV_NAME>";
				}
				name = name.replace("_" + envName, "_<ENV_NAME>").replace("_" + envName.replace("-", ""),
						"_<ENV_NAME>");
				obj.setKey(name);
				obj.setVersion((String) jsonObj.get("version"));
				obj.setDescription((String) jsonObj.get("description"));
				obj.setEndpoint((String) jsonObj.get("endpoint"));
				return obj;
			}
			return null;
		}
	}
}
