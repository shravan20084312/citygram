package com.sa.assistapp.util;

import java.io.FileOutputStream;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.sa.assistapp.constants.GenericConstants;
import com.sa.assistapp.model.SolrDocumentFiltered;

/**
 * @author lugupta
 *
 */
public class PdfWriter {

	private static final Logger logger = Logger.getLogger(PdfWriter.class);
	public static final Logger errorLogger = Logger.getLogger(GenericConstants.LOGGER_ERROR_NAME);

	private static BaseColor dataTableSubHeaderColor = new BaseColor(192, 192, 192);
	private static BaseColor dataTableSubHeaderValueColor = new BaseColor(255, 255, 255);
	private static BaseColor missingInEnv = new BaseColor(246, 255, 14);
	private static Font datatableSubHeaderValueFont = new Font(FontFamily.UNDEFINED, 6, Font.NORMAL,
			new BaseColor(0, 0, 0));

	public void write(String outputFilePath, List<SolrDocumentFiltered> solrKeysList, Set<String> unavailableKeys,
			String coreNameL4, String coreNameEnv, int keysCountL4, int keysCountEnv, String envName) throws Exception {
		com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
		com.itextpdf.text.pdf.PdfWriter docWriter = null;
		try {
			// Initialize PDF Instance
			// PDF Generation
			docWriter = com.itextpdf.text.pdf.PdfWriter.getInstance(doc, new FileOutputStream(outputFilePath));

			// document header attributes
			doc.addAuthor("Luv Gupta");
			doc.addCreationDate();
			doc.addProducer();
			doc.addCreator("Luv Gupta");
			doc.addTitle("SA-AssistApp");
			doc.setPageSize(PageSize.LETTER);

			// open document
			doc.open();

			Font comparatorHeaderTitleFont = new Font(FontFamily.UNDEFINED, 6, Font.BOLD, new BaseColor(0, 0, 0));
			Font comparatorHeaderValueFont = new Font(FontFamily.UNDEFINED, 6);

			BaseColor comparatorHeaderDefaultColor = new BaseColor(223, 233, 244);

			float[] comparatorHeaderColumnWidths;

			comparatorHeaderColumnWidths = new float[] { 3f, 3f, 3f, 3f, 3f, 2f };

			PdfPTable comparatorHeader = new PdfPTable(comparatorHeaderColumnWidths);
			// set table width a percentage of the page width
			comparatorHeader.setWidthPercentage(100f);

			// insert column headings
			insertCell(comparatorHeader, "Environment", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderTitleFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, "Total SOLR keys in L4", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderTitleFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, "Total SOLR keys in " + envName.substring(0, 2), Element.ALIGN_CENTER,
					Element.ALIGN_CENTER, 1, comparatorHeaderTitleFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, "L4 SOLR Core", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderTitleFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, envName.substring(0, 2) + " SOLR Core", Element.ALIGN_CENTER,
					Element.ALIGN_CENTER, 1, comparatorHeaderTitleFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, "Missing in " + envName, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderTitleFont, comparatorHeaderDefaultColor);

			comparatorHeader.setHeaderRows(1);

			insertCell(comparatorHeader, envName, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderValueFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, String.valueOf(keysCountL4), Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderValueFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, String.valueOf(keysCountEnv), Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderValueFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, coreNameL4, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderValueFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, coreNameEnv, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					comparatorHeaderValueFont, comparatorHeaderDefaultColor);
			insertCell(comparatorHeader, String.valueOf(unavailableKeys.size()), Element.ALIGN_CENTER,
					Element.ALIGN_CENTER, 1, comparatorHeaderValueFont, missingInEnv);

			// paragraph1.add(table);
			doc.add(comparatorHeader);

			// Main Table
			Font dataTableHeaderTitleFont = new Font(FontFamily.UNDEFINED, 6, Font.BOLD, new BaseColor(255, 255, 255));

			BaseColor dataTableHeaderDefaultColor = new BaseColor(42, 130, 191);

			float[] dataTableHeaderColumnWidths;

			dataTableHeaderColumnWidths = new float[] { 5f, 1f, 3f, 5f };

			PdfPTable dataTableHeader = new PdfPTable(dataTableHeaderColumnWidths);

			dataTableHeader.setSpacingBefore(5f);
			// set table width a percentage of the page width
			dataTableHeader.setWidthPercentage(100f);
			// insert column headings

			insertCell(dataTableHeader, "SOLR keys validation results for " + envName, Element.ALIGN_CENTER,
					Element.ALIGN_CENTER, 4, dataTableHeaderTitleFont, dataTableHeaderDefaultColor);

			insertCell(dataTableHeader, "Key Name", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					dataTableHeaderTitleFont, dataTableHeaderDefaultColor);
			insertCell(dataTableHeader, "Version", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					dataTableHeaderTitleFont, dataTableHeaderDefaultColor);
			insertCell(dataTableHeader, "Description", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					dataTableHeaderTitleFont, dataTableHeaderDefaultColor);
			insertCell(dataTableHeader, "Endpoint", Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
					dataTableHeaderTitleFont, dataTableHeaderDefaultColor);

			dataTableHeader.setHeaderRows(1);

			appendInputDataForViewer(solrKeysList, unavailableKeys, dataTableHeader);
			// Saving PDF
			doc.add(dataTableHeader);
		} catch (Exception e) {
			errorLogger.error(
					"-------------------------------------------------------------------------------------------------------------------------");
			errorLogger.error("Classname: PdfWriter. Error in method write(): " + e);
			errorLogger.error(
					"-------------------------------------------------------------------------------------------------------------------------");
			logger.error("Classname: PdfWriter. Error in method write(): " + e);
			throw e;
		} finally {
			if (doc != null) {
				// close the document
				doc.close();
			}
			if (docWriter != null) {
				// close the writer
				docWriter.close();
			}
		}

	}

	/**
	 * Processes Input Data and converts them into PDF output for Split Viewer
	 */
	private void appendInputDataForViewer(List<SolrDocumentFiltered> solrKeysList, Set<String> unavailableKeys,
			PdfPTable dataTableHeader) {
		int counter = 1;
		for (SolrDocumentFiltered solrKey : solrKeysList) {
			String key = solrKey.getKey();
			String version = solrKey.getVersion();
			String desc = solrKey.getDescription();
			String endpoint = solrKey.getEndpoint();
			boolean highlight = false;

			if (!unavailableKeys.contains(key)) {
				highlight = true;
			}

			if (counter % 2 == 0) {
				insertCell(dataTableHeader, key, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderColor);
				insertCell(dataTableHeader, version, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderColor);
				insertCell(dataTableHeader, desc, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderColor);
				insertCell(dataTableHeader, highlight ? "" : endpoint, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, highlight ? missingInEnv : dataTableSubHeaderColor);
			} else {
				insertCell(dataTableHeader, key, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderValueColor);
				insertCell(dataTableHeader, version, Element.ALIGN_CENTER, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderValueColor);
				insertCell(dataTableHeader, desc, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, dataTableSubHeaderValueColor);
				insertCell(dataTableHeader, highlight ? "" : endpoint, Element.ALIGN_LEFT, Element.ALIGN_CENTER, 1,
						datatableSubHeaderValueFont, highlight ? missingInEnv : dataTableSubHeaderValueColor);
			}
			counter++;
		}

	}

	/**
	 * Inserts Cells into PDF Table
	 */
	private static void insertCell(PdfPTable table, String text, int align, int valign, int colspan, Font font,
			BaseColor baseColor) {

		// create a new cell with the specified Text and Font
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		// set the cell alignment
		cell.setHorizontalAlignment(align);
		cell.setVerticalAlignment(valign);
		// set the cell column span in case you want to merge two or more cells
		cell.setColspan(colspan);
		// in case there is no text and you wan to create an empty row
		if (text.trim().equalsIgnoreCase("")) {
			cell.setMinimumHeight(10f);
		}
		// set the background color
		cell.setBackgroundColor(baseColor);

		cell.setPaddingTop(4f);
		cell.setPaddingBottom(4f);
		// add the call to the table
		table.addCell(cell);
	}

	public static Boolean isEmpty(String inputString) {
		Boolean isEmpty = Boolean.FALSE;
		if (null == inputString || inputString.trim().equals("")) {
			isEmpty = Boolean.TRUE;
		}
		return isEmpty;
	}

}
