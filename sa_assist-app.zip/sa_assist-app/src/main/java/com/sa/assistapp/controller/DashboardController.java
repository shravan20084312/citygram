/**
 * 
 */
package com.sa.assistapp.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.CoreAdminRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sa.assistapp.constants.GenericConstants;
import com.sa.assistapp.form.DashboardForm;
import com.sa.assistapp.service.DashboardService;
import com.sa.assistapp.util.DateUtil;

/**
 * This class renders the Employee Certify Server screen
 * 
 * @author lugupta
 */
@Controller
@PropertySource("classpath:sa-assistapp.properties")
public class DashboardController {

	private static final Logger logger = Logger.getLogger(DashboardController.class);
	public static final Logger errorLogger = Logger.getLogger(GenericConstants.LOGGER_ERROR_NAME);

	@Autowired
	private Environment env;

	@Autowired
	DashboardService dashboardService;

	/**
	 * This method shows the list of all the employees
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = GenericConstants.URL_DASHBOARD, method = RequestMethod.GET)
	public String showDashboard(@ModelAttribute("dashboardForm") DashboardForm dashboardForm, Model model) {
		try {
			dashboardForm.setEnvName(env.getProperty("default.envname"));
			dashboardForm.setDomainName(env.getProperty("default.domainname"));
			model.addAttribute("dashboardForm", dashboardForm);
			model.addAttribute("welcomeMsg", this.getLoggedInUserAndDate());
		} catch (Exception e) {
			errorLogger.error(
					"Classname: DashboardController - showDashboard(). Error in loading Certify Server page: " + e);
			logger.error("showDashboard() - Error in loading Certify Server page: " + e);
			model.addAttribute("message",
					"Error in loading Certify Server page. Please contact helpdesk for assistance. " + e);

			return GenericConstants.PAGE_ERROR;
		}

		return GenericConstants.PAGE_DASHBOARD;
	}

	/**
	 * Get the Full Name and Current Date of the logged in user
	 * 
	 * @return
	 */
	private String getLoggedInUserAndDate() {
		try {
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

			return "Welcome <b>" + dashboardService.findFullNameByUserName(user.getUsername()) + "</b>. " + "\t"
					+ " Logged on: " + DateUtil.getDayAndDateInString(new Date());
		} catch (Exception e) {
			errorLogger.error("Classname: DashboardController. Guest login: " + e);
			return "Welcome <b>Guest</b>";
		}
	}

	@RequestMapping(value = "/{envName}/checkSolrKeyAjax", method = RequestMethod.GET)
	@ResponseBody
	public String checkSolrKeyAjax(@PathVariable(value = "envName") String envName) {
		try {
			dashboardService.validateSolrKeys(envName);
			logger.info("checkSolrKeyAjax() - SOLR keys validated with PROD for environment: " + envName);

			return GenericConstants.STRING_PASS;
		} catch (Exception e) {
			errorLogger.error(
					"Classname: DashboardController - checkSolrKeyAjax(). Error in loading Certify Server page. : "
							+ e);
			logger.error("checkSolrKeyAjax() - Error in loading Certify Server page: " + e);
			return GenericConstants.STRING_FAIL;
		}
	}

	@RequestMapping(value = "/{envName}/clearSolrCacheAjax", method = RequestMethod.GET)
	@ResponseBody
	public String clearSolrCacheAjax(@PathVariable(value = "envName") String envName) {
		try {
			String coreName = null, baseSolrUlr = null;

			if (envName.equalsIgnoreCase(env.getProperty("default.envname"))) {
				baseSolrUlr = env.getProperty("solr.l2.url");
				coreName = env.getProperty("solr.l2.core");
			} else {
				baseSolrUlr = env.getProperty("solr.l1.url");
				coreName = env.getProperty("solr.l1.core");
			}

			HttpSolrClient solrClient = new HttpSolrClient.Builder().withBaseSolrUrl(baseSolrUlr).build();
			// solrClient.setParser(new XMLResponseParser());
			logger.info("clearSolrCacheAjax() - SOLR Ping status" + solrClient.ping());
			CoreAdminRequest.reloadCore(coreName, solrClient);
			logger.info("clearSolrCacheAjax() - core reloaded successfully for environment: " + envName);

			return GenericConstants.STRING_PASS;
		} catch (Exception e) {
			errorLogger.error(
					"Classname: DashboardController - clearSolrCacheAjax(). Error in loading Certify Server page. : "
							+ e);
			logger.error("clearSolrCacheAjax() - Error in loading Certify Server page. MalformedURLException: " + e);
			return GenericConstants.STRING_FAIL;
		}
	}

	@RequestMapping(value = "/{envName}/dnsCheckAjax", method = RequestMethod.GET)
	@ResponseBody
	public String dnsCheckAjax(@PathVariable(value = "envName") String envName,
			@RequestParam("domainName") String domainName) {
		boolean isValid;

		try {
			isValid = dashboardService.pingURL(domainName, GenericConstants.TIMEOUT);

			return isValid ? GenericConstants.STRING_PASS : GenericConstants.STRING_FAIL;
		} catch (MalformedURLException e) {
			errorLogger.error(
					"Classname: DashboardController - dnsCheckAjax(). Error in loading Certify Server page. MalformedURLException: "
							+ e);
			logger.error("dnsCheckAjax() - Error in loading Certify Server page. MalformedURLException: " + e);
			return GenericConstants.STRING_FAIL;
		} catch (UnknownHostException e) {
			errorLogger.error(
					"Classname: DashboardController - dnsCheckAjax(). Error in loading Certify Server page. UnknownHostException: "
							+ e);
			logger.error("dnsCheckAjax() - Error in loading Certify Server page. UnknownHostException: " + e);
			return GenericConstants.STRING_FAIL;
		} catch (IOException e) {
			errorLogger.error(
					"Classname: DashboardController - dnsCheckAjax(). Error in loading Certify Server page. IOException: "
							+ e);
			logger.error("dnsCheckAjax() - Error in loading Certify Server page. IOException: " + e);
			return GenericConstants.STRING_FAIL;
		}
	}

	@RequestMapping(value = "/{envName}/loginCheckAjax", method = RequestMethod.GET)
	@ResponseBody
	public String loginCheckAjax(@PathVariable(value = "envName") String envName) {
		try {
			logger.info("loginCheckAjax() - Default users login access validated for environment: " + envName);

			return GenericConstants.STRING_PASS;
		} catch (Exception e) {
			errorLogger.error(
					"Classname: DashboardController - loginCheckAjax(). Error in loading Certify Server page. : " + e);
			logger.error("loginCheckAjax() - Error in loading Certify Server page: " + e);
			return GenericConstants.STRING_FAIL;
		}
	}
}
